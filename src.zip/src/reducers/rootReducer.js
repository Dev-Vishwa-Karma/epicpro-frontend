import { combineReducers } from 'redux';
import settings from './settings';
export default combineReducers({
    settings
});