// BreakReasonModal.js
import React from 'react';
import InputField from '../../../common/formInputs/InputField';
import Button from '../../../common/formInputs/Button';

const BreakReasonModal = ({ showModal, breakReason, handleReasonChange, handleSaveBreakIn, closeModal, ButtonLoading, errors = {} }) => {
  return (
    <>
    {showModal && (
      <div className="modal fade show d-block" id="addBreakReasonModal" tabIndex="-1" role="dialog">
        <div className="modal-dialog" role="dialog" style={{ maxHeight: '80vh', overflowY: 'auto' }}>
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Break Reason</h5>
              <button type="button" className="close" onClick={closeModal} aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="dimmer-content">
              <div className="modal-body">
                <div className="row clearfix">
                  <div className="col-md-12">
                    <InputField
                      label="Break Reason"
                      name="breakReason"
                      type="textarea"
                      value={breakReason}
                      onChange={handleReasonChange}
                      error={errors.breakReason}
                      placeholder="Please provide the reason for your break"
                      rows={10}
                      refInput={errors.breakReason ? (el) => el && el.focus() : null}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <Button
                label={ButtonLoading ? "Saving..." : "Save changes"}
                onClick={handleSaveBreakIn}
                disabled={ButtonLoading}
                className="btn-primary"
                loading={ButtonLoading}
                icon={ButtonLoading ? "" : "fa fa-save"}
                iconStyle={{ marginRight: '8px' }}
              />
            </div>
          </div>
        </div>
      </div>
    )}
    {showModal && <div className="modal-backdrop fade show" />}
    </>
  );
};

export default BreakReasonModal;
