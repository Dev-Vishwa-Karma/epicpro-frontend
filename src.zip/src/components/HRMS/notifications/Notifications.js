import React, { Component } from 'react'
import { connect } from 'react-redux';
import AlertMessages from '../../common/AlertMessages';
import NotificationTable from './elements/NotificationTable';
import { getService } from '../../../services/getService';
import DeleteModal from '../../common/DeleteModal';
import NotificationModal from './elements/NotificationModal';
import Pagination from '../../common/Pagination';
import DateFilterForm from '../../common/DateFilterForm';
import TableSkeleton from '../../common/skeletons/TableSkeleton';
import { formatDate, getToday } from '../../../utils';
import { appendDataToFormData } from '../../../utils';
class Notifications extends Component {
    constructor(props) {
		super(props);
		this.state = {
            notificationData: [],
            employeeData:[],
            filterFromDate: getToday(),
            filterToDate: getToday(),
            filterEmployeeId:"",
            loading: true,
            notificationToDelete: null,
			successMessage: "",
            errorMessage: "",
            showSuccess: false, 
            showError: false,
            ButtonLoading: false,
            showModal:false,
            selectedNotification: null,
            title:"",
            body:"",
            type:"",
            read:0,
            col: (window.user.role === "admin" || window.user.role === "super_admin") ? 2 : 2,
            selectedEmployee: '',
            // Pagination state variables
            currentPage: 1,
            dataPerPage: 10
		};
	}

    componentDidMount() {
        this.getNotifications()
        this.getEmployees()
       // this.markAsRead();
    }

    getNotifications = () => {
        const { filterFromDate,filterToDate } = this.state;
        let requestData = {
            action: 'get_notifications'
        };

        if (filterFromDate) {
            requestData.start_date = filterFromDate;
        }

        if (filterToDate) {
            requestData.end_date = filterToDate;
        }

        if (window.user.id) {
            requestData.user_id = window.user.id;
        }

        getService.getCall('notifications.php', requestData)
            .then(data => {
                if (data.status === 'success') {
                    this.setState({ notificationData: data.data, loading: false }); 
                } else {
                    this.setState({ notificationData: [], message: data.message, loading: false });
                }
            })
            .catch(err => {
                this.setState({ message: 'Failed to fetch data', loading: false });
                console.error(err);
        });
    }

    // markAsRead = (notification_id) => {
    //  getService.getCall('notifications.php', {
    //         action: 'mark_read',
    //         user_id:window.user.id,
    //     }).then(data => {
    //     if (data.status === "success") {
    //         this.setState({
    //         page: 1,
    //         notifications: [], 
    //     }, () => {
    //         this.getNotifications(); 
    //     });
    //     } else {
    //     console.error('Error marking notification as read');
    //     }
    //     })
    // .catch((err) => {
    //     console.error('Error marking notification as read', err);
    // });
    // };
    

    getEmployees = () => {
        getService.getCall('get_employees.php', {
            action: 'view',
            role:'employee',

        })
        .then(data => {
            if (data.status === 'success') {
            this.setState({ employeeData: data.data });
            } else {
            this.setState({ error: data.message });
            }
        })
        .catch(err => {
            this.setState({ error: 'Failed to fetch data' });
            console.error(err);
        });
    }

    handleApplyFilter = async () => {
        this.setState({ currentPage: 1 }, () => {
            this.getNotifications();
        });
    };

    openModal = (notificationId) => {
        this.setState({
            notificationToDelete: notificationId,
        });
    };

    onCloseDeleteModal = () => {
        this.setState({ notificationToDelete: null });
    }

    onCloseAddEdit = () => {
    this.setState({ showModal: false,
            selectedNotification: null, 
            selectedEmployee:'',
            errors: {},
            ButtonLoading: false
        })
    } 

    confirmDelete = () => {
        const { notificationToDelete, currentPage, notificationData, dataPerPage } = this.state;
        if (!notificationToDelete) return;

        this.setState({ ButtonLoading: true });
        
        getService.deleteCall('notifications.php','delete', notificationToDelete )
        .then((data) => {
        if (data.success) {
            // Update notifications state after deletion
            const updatedNotifications = notificationData.filter((d) => d.id !== notificationToDelete);

            // Calculate the total pages after deletion
            const totalPages = Math.ceil(updatedNotifications.length / dataPerPage);

            // Adjust currentPage if necessary (if we're on a page that no longer has data)
            let newPage = currentPage;
            if (updatedNotifications.length === 0) {
                newPage = 1;
            } else if (currentPage > totalPages) {
                newPage = totalPages;
            }

            this.setState((prevState) => ({
                notificationData: updatedNotifications,
                currentPage: newPage,
                successMessage: "Notification deleted successfully",
                showSuccess: true,
                errorMessage: '',
                showError: false,
                ButtonLoading: false,
            }));
            this.onCloseDeleteModal();
            setTimeout(this.dismissMessages, 3000);
        } else {
            this.setState({
                errorMessage: "Failed to delete notification",
                showError: true,
                successMessage: '',
                showSuccess: false,
                ButtonLoading: false,
            });
            setTimeout(this.dismissMessages, 3000);
        }
        })
        .catch((error) => {
            console.error("Error:", error);
            this.setState({
                ButtonLoading: false,
            });
        });
        
    };

    // Handle Pagination of notifications listing
    handlePageChange = (newPage) => {
        const totalPages = Math.ceil(this.state.notificationData.length / this.state.dataPerPage);
        if (newPage >= 1 && newPage <= totalPages) {
            this.setState({ currentPage: newPage });
        }
    };

    handleAddClick = () => {
        this.setState({ 
            showModal: true, 
            selectedNotification: null,
            errors: {} 
        });
    }

    handleEditClick = (notification) => {
        this.setState({
            selectedNotification: { ...notification },
            selectedEmployee: notification.employee_id,
            showModal: true,
            errors: {}
        });
    };

    getFormData = () => {
        const { selectedNotification } = this.state;
        if (selectedNotification) {
            return selectedNotification;
        } else {
            return {
                title: this.state.title,
                body: this.state.body,
                type: this.state.type,
                read: this.state.read
            };
        }
    };

    handleInputChangeForAddNotification = (event) => {
        const { name, value } = event.target;
        this.setState({ 
            [name]: value,
            errors: { ...this.state.errors, [name]: "" }
        });
    };

    handleInputChange = (e) => {
        const { name, value } = e.target;
        this.setState((prevState) => ({
            selectedNotification: {
                ...prevState.selectedNotification,
                [name]: value, // Dynamically update the field
            },
            errors: {
                ...prevState.errors,
                [name]: "", // Clear error when typing
            }
        }));
    };
    
    handleEmployeeChange = (event) => {
            this.setState({ selectedEmployee: event.target.value });
    };

    handleDateChange = (date, type) => {
        if (date) {
        const newDate = formatDate(new Date(date));
        if (type === 'fromDate') {
            this.setState({ filterFromDate: newDate });
            
        } else if (type === 'toDate') {
            this.setState({ filterToDate: newDate });
        }

        } else {
        this.setState({ [type]: null });
        }
    };

    validateNotificationForm = (title, body, type) => {
        let errors = {};
        let isValid = true;

        if (!title.trim()) {
            errors.title = "Title is required.";
            isValid = false;
        }

        if (!body.trim()) {
            errors.body = "Body is required.";
            isValid = false;
        }

        if (!type.trim()) {
            errors.type = "Type is required.";
            isValid = false;
        }

        return { isValid, errors };
    };

    addNotification = () => {
        const { title, body, type, read, selectedEmployee} = this.state;

        const { isValid, errors } = this.validateNotificationForm(title, body, type);
        if (!isValid) {
            this.setState({ errors });
            return; 
        }

        this.setState({ ButtonLoading: true });
        const addNotificationFormData = new FormData();

        const data = {
            title: title,
            body: body,
            type: type,
            read: read,
            employee_id:selectedEmployee
        }
        appendDataToFormData(addNotificationFormData, data)

        // API call to add Notification
        getService.addCall('notifications.php','add', addNotificationFormData)
        .then((data) => {
            if (data.success) {
                // Update the Notification list
                this.setState((prevState) => ({
                    notificationData: [...(prevState.notificationData || []), data.newNotification],
                    title: "",
                    body: "",
                    read:0,
                    type: "",
                    selectedEmployee:'',
                    successMessage: "Notification added successfully!",
                    showSuccess: true,
                    ButtonLoading: false
                }));

                this.onCloseAddEdit();
                setTimeout(this.dismissMessages, 3000);
            } else {
                this.setState({
                    errorMessage: "Failed to add Notification. Please try again.",
                    showError: true,
                    ButtonLoading: false
                });

                setTimeout(this.dismissMessages, 3000);
            }
        })
        .catch((error) => {
            console.error("Error:", error);
            this.setState({
                errorMessage: "An error occurred while adding the Notification.",
                showError: true,
                ButtonLoading: false
            });
            setTimeout(this.dismissMessages, 3000);
        });
    };

    editNotification = () => {
        const {title, body, type, selectedEmployee} = this.state;

        const { isValid, errors } = this.validateNotificationForm(title, body, type);
        if (!isValid) {
            this.setState({ errors });
            return; 
        }
        this.setState({ ButtonLoading: true });
        const { selectedNotification } = this.state;
        if (!selectedNotification) return;
        const editNotificationFormData = new FormData();
        
        const data = {
            title: selectedNotification.title,
            body: selectedNotification.body,
            type: selectedNotification.type,
            read: selectedNotification.read,
            employee_id: selectedEmployee,
            id:selectedNotification.id
        }
        appendDataToFormData(editNotificationFormData, data)
        getService.editCall('notifications.php','edit', editNotificationFormData)
        .then((data) => {
            if (data.status == 'success') {
               this.setState((prevState) => {
                    const updateNotificationData = prevState.notificationData.map((notification) =>
                        notification.id === selectedNotification.id ? { ...notification, ...data.updatedNotificationData } : notification
                    );
                    return {
                        notificationData: updateNotificationData,
                        successMessage: 'Notification updated successfully',
						showSuccess: true,
                        errorMessage: '',
					    showError: false,
                        ButtonLoading: false
                    };
                });
                setTimeout(this.dismissMessages, 3000);
                this.onCloseAddEdit()
            } else {
                this.setState({ 
                    errorMessage: "Failed to update notification",
                    showError: true,
                    successMessage: '',
                    showSuccess: false,
                    ButtonLoading: false
                });
                setTimeout(this.dismissMessages, 3000);
            }
        })
        .catch((error) => {
            console.error("Error:", error);
            this.setState({
                errorMessage: "Error updating notification:", error,
                showError: true,
                successMessage: '',
                showSuccess: false,
                ButtonLoading: false
            });
            setTimeout(this.dismissMessages, 3000);
        });
    };
    
    
    dismissMessages = () => {
        this.setState({
            showSuccess: false,
            successMessage: "",
            showError: false,
            errorMessage: "",
        });
    };

    render() {
        const { fixNavbar } = this.props;
        const { notificationData, message, loading, showSuccess, successMessage, showError, errorMessage, col, selectedNotification, showModal, selectedEmployee, employeeData, currentPage, dataPerPage } = this.state;
        
        // Pagination logic for notifications
        const indexOfLastNotification = currentPage * dataPerPage;
        const indexOfFirstNotification = indexOfLastNotification - dataPerPage;
        const currentNotifications = notificationData.slice(indexOfFirstNotification, indexOfLastNotification);
        const totalPages = Math.ceil(notificationData.length / dataPerPage);
        
        return (
            <>
                <AlertMessages
                    showSuccess={showSuccess}
                    successMessage={successMessage}
                    showError={showError}
                    errorMessage={errorMessage}
                    setShowSuccess={(val) => this.setState({ showSuccess: val })}
                    setShowError={(val) => this.setState({ showError: val })}
                />
                <div className={`section-body ${fixNavbar ? "marginTop" : ""} `}>
                    <div className="container-fluid">
                        <div className="card">
                            <div className="card-body">
                                <div className="row">
                                    <DateFilterForm
                                        fromDate={this.state.filterFromDate}
                                        toDate={this.state.filterToDate}
                                        ButtonLoading={this.state.ButtonLoading}
                                        handleDateChange={this.handleDateChange}
                                        handleApplyFilters={this.handleApplyFilter}
                                        col={col}
                                    />
                                    {/* <div className={`col-md-${col}`}>
                                        <Button
                                        label="Add"
                                        onClick={() => this.handleAddClick()}
                                        className="btn-primary"
                                        style={{ float: "right", marginTop: 34 }}
                                        icon="fe fe-plus"
                                        iconStyle={{ marginRight: '8px' }}
                                        dataToggle="modal"
                                        dataTarget="#addBreakModal"
                                        />
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="section-body mt-3">
                    <div className="container-fluid">
                        <div className="tab-content mt-3">
                            <div className="tab-pane fade show active" id="Notifications-list" role="tabpanel">
                                <div className="card">
                                    <div className="card-header">
                                        <h3 className="card-title">Notification List</h3>
                                        <div className="card-options">
                                        </div>
                                    </div>
                                    <div className="card-body">
                                        {loading ? (
                                            <div className="card-body">
                                                <div className="dimmer active">
                                                     <TableSkeleton columns={6} rows={currentNotifications.length} />
                                                </div>
                                            </div>
                                        ) : (
                                            <>
                                                <NotificationTable 
                                                    notificationData={currentNotifications} 
                                                    message={message}
                                                   // onEditClick={this.handleEditClick} 
                                                    onDeleteClick={this.openModal} 
                                                    userRole={window.user.role}
                                                />
                                                {/* Pagination inside card body */}
                                                {totalPages > 1 && (
                                                    <div className="d-flex justify-content-end mt-3">
                                                        <Pagination
                                                            currentPage={currentPage}
                                                            totalPages={totalPages}
                                                            onPageChange={this.handlePageChange}
                                                        />
                                                    </div>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <NotificationModal
                    isEdit={!!selectedNotification}
                    show={showModal}
                    modalId="notificationModal"
                    onClose={this.onCloseAddEdit}
                    onSubmit={selectedNotification ? this.editNotification : this.addNotification}
                    onChange={selectedNotification ? this.handleInputChange : this.handleInputChangeForAddNotification}
                    formData={this.getFormData()}
                    errors={this.state.errors}
                    loading={this.state.ButtonLoading}
                    employeeData={employeeData}
                    selectedEmployee={selectedEmployee} 
                    handleEmployeeChange={this.handleEmployeeChange} 
                />
                <DeleteModal
                    show={!!this.state.notificationToDelete}
                    onConfirm={this.confirmDelete}
                    isLoading={this.state.ButtonLoading}
                    deleteBody='Are you sure you want to delete the Notification?'
                    modalId="deleteNotificationModal"
                    onClose={this.onCloseDeleteModal}
                />
            </>
        )
    }
}
const mapStateToProps = state => ({
    fixNavbar: state.settings.isFixNavbar
})

const mapDispatchToProps = dispatch => ({})
export default connect(mapStateToProps, mapDispatchToProps)(Notifications);



